# SignalScope (Android)

Live Wi-Fi & mobile signal strength, a speed test, and camera-based signal heatmaps of rooms and yards.

## Features
- **Signal tab** – live dBm gauge for the active connection, Wi-Fi (SSID, RSSI, link speed, band, Wi-Fi standard) and
  cellular (carrier, dBm, LTE/5G, RSRP/RSRQ/SNR) with 90-second history graphs.
- **Speed test tab** – ping, jitter, download & upload against Cloudflare's speed servers, with history.
- **Signal maps tab** – photograph a room or yard with the camera (or use a blank grid), walk around, tap where you're
  standing, and the app records signal (and optionally speed) at that spot. An interpolated heatmap fills in, with
  best/worst spots and tips. Maps are saved on the phone.

Real dBm readings come from a small custom native module (`modules/signal-strength`, Kotlin) that reads Android's
WifiManager and TelephonyManager. Because of that, the app needs a **development or standalone build** — Expo Go will run,
but only shows approximate values.

## Build an installable APK (easiest — builds in the cloud)
Needs a computer with Node.js 20+ and a free Expo account (expo.dev).
```bash
npm install
npx eas-cli@latest login
npx eas-cli@latest build -p android --profile preview
```
When it finishes, EAS gives you a link/QR code — open it on your Android phone to download and install the APK.

## Or build locally (Android Studio + SDK installed, phone plugged in with USB debugging)
```bash
npm install
npx expo run:android
```

## Permissions it asks for
- **Camera** – to photograph the space you're mapping (photos never leave the phone).
- **Location** – Android requires it to reveal the Wi-Fi network name and nearby cell info. Location itself isn't used.
- **Phone state** – to show the data network type (4G/5G).

## Tips for good maps
- Hold the phone the same way for every reading; your body blocks signal.
- Take 8–15 readings spread evenly, including corners and spots you care about (desk, couch, patio).
- Turn on "Also test speed at each spot" to map real-world throughput, not just signal.
