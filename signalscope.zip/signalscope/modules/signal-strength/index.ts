import { requireOptionalNativeModule } from 'expo';

export type WifiReading = {
  enabled: boolean;
  connected: boolean;
  rssi?: number;
  level?: number;
  linkSpeedMbps?: number;
  txLinkSpeedMbps?: number;
  rxLinkSpeedMbps?: number;
  frequencyMHz?: number;
  ssid?: string | null;
  bssid?: string | null;
  wifiStandard?: string | null;
};

export type CellReading = {
  available: boolean;
  reason?: string;
  carrier?: string | null;
  dbm?: number;
  level?: number;
  asu?: number;
  technology?: string;
  networkType?: string;
  rsrp?: number | null;
  rsrq?: number | null;
  rssnr?: number | null;
};

type NativeSignal = {
  getWifiInfo(): WifiReading;
  getCellInfo(): CellReading;
  getActiveTransport(): string;
};

// Null when running in Expo Go / iOS / web (no custom native code available).
const Native = requireOptionalNativeModule<NativeSignal>('SignalStrength');

export const isNativeAvailable = Native != null;

export function getWifiInfo(): WifiReading | null {
  try { return Native?.getWifiInfo() ?? null; } catch { return null; }
}
export function getCellInfo(): CellReading | null {
  try { return Native?.getCellInfo() ?? null; } catch { return null; }
}
export function getActiveTransport(): string | null {
  try { return Native?.getActiveTransport() ?? null; } catch { return null; }
}
