package expo.modules.signalstrength

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.telephony.CellInfo
import android.telephony.CellInfoCdma
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.CellSignalStrength
import android.telephony.CellSignalStrengthCdma
import android.telephony.CellSignalStrengthGsm
import android.telephony.CellSignalStrengthLte
import android.telephony.CellSignalStrengthNr
import android.telephony.CellSignalStrengthWcdma
import android.telephony.TelephonyManager
import expo.modules.kotlin.exception.Exceptions
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

/**
 * Reads real radio metrics from Android:
 *  - Wi-Fi: RSSI (dBm), link speed, frequency, SSID (SSID needs location permission)
 *  - Cellular: signal dBm, level 0-4, technology (LTE / 5G NR / 3G / 2G), carrier
 */
@SuppressLint("MissingPermission", "HardwareIds")
class SignalStrengthModule : Module() {

  private val context: Context
    get() = appContext.reactContext ?: throw Exceptions.ReactContextLost()

  private fun hasPermission(permission: String): Boolean =
    context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

  override fun definition() = ModuleDefinition {
    Name("SignalStrength")

    Function("getWifiInfo") { readWifi() }
    Function("getCellInfo") { readCell() }
    Function("getActiveTransport") { activeTransport() }
  }

  private fun activeTransport(): String {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "none"
    return when {
      caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
      caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
      caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
      caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "vpn"
      else -> "other"
    }
  }

  @Suppress("DEPRECATION")
  private fun readWifi(): Map<String, Any?> {
    val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    if (!wm.isWifiEnabled) return mapOf("enabled" to false, "connected" to false)

    val info = wm.connectionInfo
    val connected = info != null && info.networkId != -1 && info.rssi > -127
    if (!connected) return mapOf("enabled" to true, "connected" to false)

    val rssi = info.rssi
    val level = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      // Scale the device-specific max level to 0..4
      val max = wm.maxSignalLevel.coerceAtLeast(1)
      Math.round(wm.calculateSignalLevel(rssi) * 4f / max)
    } else {
      WifiManager.calculateSignalLevel(rssi, 5)
    }

    var ssid: String? = info.ssid?.trim('"')
    if (ssid == null || ssid == "<unknown ssid>" || ssid.isEmpty()) ssid = null

    val result = mutableMapOf<String, Any?>(
      "enabled" to true,
      "connected" to true,
      "rssi" to rssi,
      "level" to level,
      "linkSpeedMbps" to info.linkSpeed,
      "frequencyMHz" to info.frequency,
      "ssid" to ssid,
      "bssid" to info.bssid
    )
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      result["txLinkSpeedMbps"] = info.txLinkSpeedMbps
      result["rxLinkSpeedMbps"] = info.rxLinkSpeedMbps
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      result["wifiStandard"] = when (info.wifiStandard) {
        4 -> "Wi-Fi 4 (802.11n)"
        5 -> "Wi-Fi 5 (802.11ac)"
        6 -> "Wi-Fi 6 (802.11ax)"
        7 -> "802.11ad (WiGig)"
        8 -> "Wi-Fi 7 (802.11be)"
        1 -> "Legacy (802.11a/b/g)"
        else -> null
      }
    }
    return result
  }

  private fun describe(css: CellSignalStrength): MutableMap<String, Any?> {
    val m = mutableMapOf<String, Any?>(
      "dbm" to css.dbm.takeIf { it != Int.MAX_VALUE },
      "level" to css.level,
      "asu" to css.asuLevel
    )
    when (css) {
      is CellSignalStrengthLte -> {
        m["technology"] = "LTE"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          m["rsrp"] = css.rsrp.takeIf { it != Int.MAX_VALUE }
          m["rsrq"] = css.rsrq.takeIf { it != Int.MAX_VALUE }
          m["rssnr"] = css.rssnr.takeIf { it != Int.MAX_VALUE }
        }
      }
      is CellSignalStrengthGsm -> m["technology"] = "2G (GSM)"
      is CellSignalStrengthWcdma -> m["technology"] = "3G (WCDMA)"
      is CellSignalStrengthCdma -> m["technology"] = "CDMA"
      else -> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && css is CellSignalStrengthNr) {
          m["technology"] = "5G NR"
          m["rsrp"] = css.ssRsrp.takeIf { it != Int.MAX_VALUE }
          m["rsrq"] = css.ssRsrq.takeIf { it != Int.MAX_VALUE }
          m["rssnr"] = css.ssSinr.takeIf { it != Int.MAX_VALUE }
        } else {
          m["technology"] = "Unknown"
        }
      }
    }
    return m
  }

  private fun fromCellInfo(ci: CellInfo): CellSignalStrength? = when {
    ci is CellInfoLte -> ci.cellSignalStrength
    ci is CellInfoGsm -> ci.cellSignalStrength
    ci is CellInfoWcdma -> ci.cellSignalStrength
    ci is CellInfoCdma -> ci.cellSignalStrength
    Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && ci is CellInfoNr -> ci.cellSignalStrength
    else -> null
  }

  private fun readCell(): Map<String, Any?> {
    val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
      ?: return mapOf("available" to false)

    if (tm.simState != TelephonyManager.SIM_STATE_READY) {
      return mapOf("available" to false, "reason" to "No SIM")
    }

    val base = mutableMapOf<String, Any?>(
      "available" to true,
      "carrier" to tm.networkOperatorName?.takeIf { it.isNotBlank() }
    )

    // Best source: SignalStrength (API 29+) — no permission required.
    var strengths: List<CellSignalStrength> = emptyList()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      try {
        strengths = tm.signalStrength?.cellSignalStrengths ?: emptyList()
      } catch (_: Throwable) {}
    }

    // Fallback: registered cell from allCellInfo (needs location permission).
    if (strengths.isEmpty() && hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
      try {
        strengths = tm.allCellInfo
          ?.filter { it.isRegistered }
          ?.mapNotNull { fromCellInfo(it) }
          ?: emptyList()
      } catch (_: SecurityException) {}
    }

    // Prefer 5G NR if present (NSA 5G reports LTE + NR), else the strongest.
    val described = strengths.map { describe(it) }.filter { it["dbm"] != null }
    val primary = described.firstOrNull { it["technology"] == "5G NR" }
      ?: described.maxByOrNull { (it["dbm"] as Int) }

    if (primary != null) base.putAll(primary)
    else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
      try { base["level"] = tm.signalStrength?.level } catch (_: Throwable) {}
    }

    if (hasPermission(Manifest.permission.READ_PHONE_STATE)) {
      try {
        base["networkType"] = networkTypeName(tm.dataNetworkType)
      } catch (_: SecurityException) {}
    }
    return base
  }

  private fun networkTypeName(t: Int): String = when (t) {
    TelephonyManager.NETWORK_TYPE_NR -> "5G"
    TelephonyManager.NETWORK_TYPE_LTE -> "4G LTE"
    TelephonyManager.NETWORK_TYPE_HSPAP, TelephonyManager.NETWORK_TYPE_HSPA,
    TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA,
    TelephonyManager.NETWORK_TYPE_UMTS -> "3G"
    TelephonyManager.NETWORK_TYPE_EDGE, TelephonyManager.NETWORK_TYPE_GPRS,
    TelephonyManager.NETWORK_TYPE_GSM -> "2G"
    TelephonyManager.NETWORK_TYPE_UNKNOWN -> "Unknown"
    else -> "Other"
  }
}
