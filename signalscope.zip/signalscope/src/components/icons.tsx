import React from 'react';
import Svg, { Circle, Path } from 'react-native-svg';

type P = { color: string; size?: number };

export const SignalIcon = ({ color, size = 24 }: P) => (
  <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round">
    <Path d="M5 12.5a10 10 0 0 1 14 0" />
    <Path d="M8.5 16a5 5 0 0 1 7 0" />
    <Path d="M1.5 9a15 15 0 0 1 21 0" />
    <Circle cx={12} cy={19.5} r={1.2} fill={color} />
  </Svg>
);

export const SpeedIcon = ({ color, size = 24 }: P) => (
  <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round">
    <Path d="M3.5 17a9 9 0 1 1 17 0" />
    <Path d="M12 14l4.5-5" />
    <Circle cx={12} cy={14} r={1.6} fill={color} />
  </Svg>
);

export const MapIcon = ({ color, size = 24 }: P) => (
  <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinejoin="round">
    <Path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2z" />
    <Path d="M9 4v14M15 6v14" />
  </Svg>
);
