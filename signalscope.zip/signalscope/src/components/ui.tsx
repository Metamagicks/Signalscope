import React from 'react';
import { Pressable, StyleSheet, Text, View, ViewStyle } from 'react-native';
import Svg, { Circle, Path, Polyline, Rect } from 'react-native-svg';
import { qualityColor } from '../lib/signal';
import { C } from '../lib/theme';

export function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

export function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <View style={styles.row}>
      <Text style={styles.rowLabel}>{label}</Text>
      <Text style={styles.rowValue}>{value}</Text>
    </View>
  );
}

export function Button({
  title, onPress, kind = 'primary', disabled, style,
}: { title: string; onPress: () => void; kind?: 'primary' | 'ghost' | 'danger'; disabled?: boolean; style?: ViewStyle }) {
  const bg = kind === 'primary' ? C.accent : kind === 'danger' ? '#3b1d27' : C.cardHi;
  const fg = kind === 'primary' ? '#06202a' : kind === 'danger' ? C.danger : C.text;
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [styles.btn, { backgroundColor: bg, opacity: disabled ? 0.4 : pressed ? 0.75 : 1 }, style]}
    >
      <Text style={[styles.btnText, { color: fg }]}>{title}</Text>
    </Pressable>
  );
}

export function Chip({ label, active, onPress }: { label: string; active: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={[styles.chip, active && { backgroundColor: C.accent, borderColor: C.accent }]}>
      <Text style={[styles.chipText, active && { color: '#06202a' }]}>{label}</Text>
    </Pressable>
  );
}

const polar = (cx: number, cy: number, r: number, deg: number) => {
  const a = ((deg - 90) * Math.PI) / 180;
  return { x: cx + r * Math.cos(a), y: cy + r * Math.sin(a) };
};
const arc = (cx: number, cy: number, r: number, a0: number, a1: number) => {
  const s = polar(cx, cy, r, a0);
  const e = polar(cx, cy, r, a1);
  const large = a1 - a0 > 180 ? 1 : 0;
  return `M ${s.x} ${s.y} A ${r} ${r} 0 ${large} 1 ${e.x} ${e.y}`;
};

/** 270° gauge; `value` 0–1. */
export function Gauge({ value, size = 220, color, children }: { value: number | null; size?: number; color?: string; children?: React.ReactNode }) {
  const v = value == null ? 0 : Math.max(0, Math.min(1, value));
  const stroke = 16;
  const r = size / 2 - stroke;
  const start = -135;
  const end = 135;
  const col = color ?? qualityColor(value == null ? null : v * 100);
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} style={StyleSheet.absoluteFill}>
        <Path d={arc(size / 2, size / 2, r, start, end)} stroke={C.border} strokeWidth={stroke} strokeLinecap="round" fill="none" />
        {v > 0.005 && (
          <Path d={arc(size / 2, size / 2, r, start, start + (end - start) * v)} stroke={col} strokeWidth={stroke} strokeLinecap="round" fill="none" />
        )}
        {v > 0.005 && (() => {
          const p = polar(size / 2, size / 2, r, start + (end - start) * v);
          return <Circle cx={p.x} cy={p.y} r={stroke / 2 + 3} fill={C.bg} stroke={col} strokeWidth={3} />;
        })()}
      </Svg>
      {children}
    </View>
  );
}

/** Classic 4-bar signal icon. */
export function Bars({ level, size = 22, color }: { level: number | null; size?: number; color?: string }) {
  const l = level ?? 0;
  const col = color ?? qualityColor(level == null ? null : l * 25);
  const w = size / 5.5;
  return (
    <Svg width={size} height={size}>
      {[0, 1, 2, 3].map((i) => {
        const h = (size * (i + 1)) / 4;
        return <Rect key={i} x={i * (w * 1.45)} y={size - h} width={w} height={h} rx={1.5} fill={i < l ? col : C.border} />;
      })}
    </Svg>
  );
}

export function Sparkline({ values, width, height = 54, min, max, color = C.accent }: { values: (number | null)[]; width: number; height?: number; min?: number; max?: number; color?: string }) {
  const v = values.map((x) => (x == null ? NaN : x));
  const finite = v.filter((x) => !isNaN(x));
  if (finite.length < 2) return <View style={{ width, height }} />;
  const lo = min ?? Math.min(...finite);
  const hi = max ?? Math.max(...finite);
  const span = hi - lo || 1;
  const step = width / Math.max(1, v.length - 1);
  const pts = v
    .map((x, i) => (isNaN(x) ? null : `${(i * step).toFixed(1)},${(height - 3 - ((x - lo) / span) * (height - 6)).toFixed(1)}`))
    .filter(Boolean)
    .join(' ');
  return (
    <Svg width={width} height={height}>
      <Polyline points={pts} fill="none" stroke={color} strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
    </Svg>
  );
}

export const styles = StyleSheet.create({
  card: { backgroundColor: C.card, borderRadius: 18, padding: 16, borderWidth: 1, borderColor: C.border, marginBottom: 14 },
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 7, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: C.border },
  rowLabel: { color: C.dim, fontSize: 14 },
  rowValue: { color: C.text, fontSize: 14, fontWeight: '600', flexShrink: 1, textAlign: 'right', marginLeft: 12 },
  btn: { borderRadius: 14, paddingVertical: 14, paddingHorizontal: 18, alignItems: 'center', justifyContent: 'center' },
  btnText: { fontSize: 16, fontWeight: '700' },
  chip: { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 999, borderWidth: 1, borderColor: C.border, backgroundColor: C.card, marginRight: 8 },
  chipText: { color: C.text, fontSize: 13, fontWeight: '600' },
  h1: { color: C.text, fontSize: 26, fontWeight: '800' },
  h2: { color: C.text, fontSize: 17, fontWeight: '700', marginBottom: 8 },
  dim: { color: C.dim, fontSize: 13 },
});
