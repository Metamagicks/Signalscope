import { CameraView, useCameraPermissions } from 'expo-camera';
import { router } from 'expo-router';
import React, { useRef, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Bars, Button, styles as ui } from '../../components/ui';
import { persistPhoto, saveMap, SignalMap, uid } from '../../lib/maps';
import { qualityColor, qualityLabel, useSignal } from '../../lib/signal';
import { C } from '../../lib/theme';

const defaultName = () =>
  `Map · ${new Date().toLocaleDateString([], { month: 'short', day: 'numeric' })} ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

export default function NewMapScreen() {
  const [perm, requestPerm] = useCameraPermissions();
  const cam = useRef<CameraView>(null);
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);
  const insets = useSafeAreaInsets();
  const { current: s } = useSignal();

  const create = async (bg: SignalMap['background'], id: string) => {
    const now = Date.now();
    const map: SignalMap = { id, name: defaultName(), createdAt: now, updatedAt: now, background: bg, points: [] };
    await saveMap(map);
    router.replace(`/map/${id}`);
  };

  const capture = async () => {
    if (!cam.current || busy) return;
    setBusy(true);
    try {
      const pic = await cam.current.takePictureAsync({ quality: 0.7, skipProcessing: false });
      const id = uid();
      const uri = persistPhoto(pic.uri, id);
      await create({ type: 'photo', uri, width: pic.width, height: pic.height }, id);
    } catch (e) {
      setBusy(false);
    }
  };

  const useGrid = () => create({ type: 'grid', width: 3, height: 4 }, uid());

  if (!perm) return <View style={{ flex: 1, backgroundColor: C.bg }} />;

  if (!perm.granted) {
    return (
      <View style={{ flex: 1, backgroundColor: C.bg, padding: 24, justifyContent: 'center', paddingTop: insets.top }}>
        <Text style={[ui.h1, { marginBottom: 10 }]}>Camera access</Text>
        <Text style={[ui.dim, { fontSize: 15, marginBottom: 20, lineHeight: 21 }]}>
          The camera is used to photograph the room or yard you want to map. Your photo stays on this phone.
        </Text>
        <Button title="Allow camera" onPress={requestPerm} />
        <Button title="Use a blank grid instead" kind="ghost" onPress={useGrid} style={{ marginTop: 10 }} />
        <Button title="Cancel" kind="ghost" onPress={() => router.back()} style={{ marginTop: 10 }} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      <CameraView ref={cam} style={StyleSheet.absoluteFill} facing="back" onCameraReady={() => setReady(true)} />

      {/* framing guide */}
      <View pointerEvents="none" style={[StyleSheet.absoluteFill, { justifyContent: 'center', alignItems: 'center' }]}>
        <View style={{ width: '86%', aspectRatio: 3 / 4, borderColor: 'rgba(255,255,255,0.35)', borderWidth: 1.5, borderRadius: 16 }} />
      </View>

      {/* live signal overlay */}
      <View style={[local.top, { paddingTop: insets.top + 10 }]}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Text style={{ color: '#fff', fontSize: 16, fontWeight: '600' }}>Cancel</Text>
        </Pressable>
        <View style={local.pill}>
          <Bars level={s?.quality != null ? Math.round(s.quality / 25) : null} size={16} />
          <Text style={{ color: '#fff', marginLeft: 8, fontWeight: '700' }}>
            {s?.dbm != null ? `${s.dbm} dBm` : '—'}
          </Text>
          <Text style={{ color: qualityColor(s?.quality ?? null), marginLeft: 6, fontWeight: '700' }}>
            {qualityLabel(s?.quality ?? null)}
          </Text>
        </View>
      </View>

      <View style={[local.bottom, { paddingBottom: insets.bottom + 18 }]}>
        <Text style={local.tip}>
          Frame the whole space — shoot from a doorway or corner for a room, or from a high spot (window, balcony) for a yard.
          A top-down view works best.
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%', paddingHorizontal: 28 }}>
          <Pressable onPress={useGrid} style={local.side}>
            <Text style={{ color: '#fff', fontWeight: '600', textAlign: 'center' }}>Blank{'\n'}grid</Text>
          </Pressable>
          <Pressable onPress={capture} disabled={!ready || busy} style={[local.shutter, (!ready || busy) && { opacity: 0.5 }]}>
            {busy ? <ActivityIndicator color="#000" /> : <View style={local.shutterInner} />}
          </Pressable>
          <View style={local.side} />
        </View>
      </View>
    </View>
  );
}

const local = StyleSheet.create({
  top: { position: 'absolute', top: 0, left: 0, right: 0, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 18 },
  pill: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.55)', paddingHorizontal: 12, paddingVertical: 7, borderRadius: 999 },
  bottom: { position: 'absolute', bottom: 0, left: 0, right: 0, alignItems: 'center', paddingTop: 16, backgroundColor: 'rgba(0,0,0,0.45)' },
  tip: { color: '#e5e7eb', fontSize: 13, textAlign: 'center', paddingHorizontal: 28, marginBottom: 16, lineHeight: 18 },
  shutter: { width: 76, height: 76, borderRadius: 38, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  shutterInner: { width: 62, height: 62, borderRadius: 31, borderWidth: 2, borderColor: '#000' },
  side: { width: 64, alignItems: 'center' },
});
