import { Image } from 'expo-image';
import { Stack, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, GestureResponderEvent, ScrollView, Switch, Text, TextInput, useWindowDimensions, View } from 'react-native';
import Svg, { Circle, G, Line, Rect, Text as SvgText } from 'react-native-svg';
import { Bars, Button, Card, Chip, Row, styles } from '../../components/ui';
import { buildHeatGrid, formatValue, HeatMetric, METRIC_LABEL, pointQuality, pointValue, summarize } from '../../lib/heatmap';
import { getMap, MapPoint, saveMap, SignalMap, uid } from '../../lib/maps';
import { qualityColor, qualityLabel, sampleSignal, useSignal } from '../../lib/signal';
import { quickDownloadProbe } from '../../lib/speedtest';
import { C } from '../../lib/theme';

const COLS = 40;

export default function MapEditor() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { width: screenW } = useWindowDimensions();
  const { current: live } = useSignal();

  const [map, setMap] = useState<SignalMap | null>(null);
  const [metric, setMetric] = useState<HeatMetric>('wifi');
  const [showHeat, setShowHeat] = useState(true);
  const [withSpeed, setWithSpeed] = useState(false);
  const [pending, setPending] = useState<{ x: number; y: number; stage: string } | null>(null);
  const abort = useRef<AbortController | null>(null);

  useEffect(() => {
    getMap(id).then((m) => {
      setMap(m);
      if (m && !m.points.some((p) => p.wifi != null) && m.points.some((p) => p.cell != null)) setMetric('cell');
    });
    return () => abort.current?.abort();
  }, [id]);

  // Default the metric to whatever the phone is using right now, for brand-new maps.
  useEffect(() => {
    if (map && map.points.length === 0 && live?.transport === 'cellular' && metric === 'wifi') setMetric('cell');
  }, [live?.transport, map?.points.length]);

  const update = async (m: SignalMap) => setMap(await saveMap(m));

  const W = screenW - 32;
  const aspect = map ? map.background.width / map.background.height : 0.75;
  const H = W / aspect;
  const rows = Math.max(4, Math.round(COLS / aspect));

  const heat = useMemo(
    () => (map && showHeat ? buildHeatGrid(map.points, metric, COLS, rows, aspect) : []),
    [map?.points, metric, showHeat, rows, aspect]
  );
  // Built once per data change, not on every live-signal tick (the screen re-renders every second).
  const heatRects = useMemo(() => {
    const cw = W / COLS;
    const ch = H / rows;
    return heat.map((c) => (
      <Rect
        key={`${c.col}-${c.row}`}
        x={Math.round(c.col * cw)}
        y={Math.round(c.row * ch)}
        width={Math.round((c.col + 1) * cw) - Math.round(c.col * cw)}
        height={Math.round((c.row + 1) * ch) - Math.round(c.row * ch)}
        fill={qualityColor(c.q)}
        fillOpacity={0.5 * c.alpha}
      />
    ));
  }, [heat, W, H, rows]);
  const stats = useMemo(() => (map ? summarize(map.points, metric) : null), [map?.points, metric]);

  const onTap = async (e: GestureResponderEvent) => {
    if (!map || pending) return;
    const x = Math.max(0, Math.min(1, e.nativeEvent.locationX / W));
    const y = Math.max(0, Math.min(1, e.nativeEvent.locationY / H));
    setPending({ x, y, stage: 'Hold still… 6s' });
    try {
      const sample = await sampleSignal((left) => setPending({ x, y, stage: `Hold still… ${left}s` }));
      let down: number | null = null;
      if (withSpeed || metric === 'down') {
        setPending({ x, y, stage: 'Testing speed…' });
        abort.current = new AbortController();
        down = await quickDownloadProbe(abort.current.signal);
      }
      const point: MapPoint = {
        id: uid(), x, y, t: Date.now(),
        wifi: sample.wifi, cell: sample.cell, down,
        ssid: sample.snap.wifi?.ssid ?? null,
      };
      await update({ ...map, points: [...map.points, point] });
    } finally {
      setPending(null);
    }
  };

  const undo = () => map && map.points.length && update({ ...map, points: map.points.slice(0, -1) });
  const clear = () =>
    map &&
    Alert.alert('Clear all readings?', 'The photo is kept.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Clear', style: 'destructive', onPress: () => update({ ...map, points: [] }) },
    ]);

  if (!map) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: C.bg }}>
        <ActivityIndicator color={C.accent} />
      </View>
    );
  }

  const liveVal = metric === 'wifi' ? live?.wifi?.rssi : metric === 'cell' ? live?.cell?.dbm : null;
  const liveQ = liveVal != null ? pointQuality({ wifi: live?.wifi?.rssi ?? null, cell: live?.cell?.dbm ?? null, down: null } as MapPoint, metric) : null;
  return (
    <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 48 }}>
      <Stack.Screen options={{ title: map.name }} />

      {/* live reading */}
      <Card style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 12 }}>
        <Bars level={liveQ != null ? Math.round(liveQ / 25) : null} size={26} />
        <View style={{ marginLeft: 12, flex: 1 }}>
          <Text style={styles.dim}>Live · {METRIC_LABEL[metric]}</Text>
          <Text style={{ color: C.text, fontSize: 20, fontWeight: '800' }}>
            {metric === 'down' ? 'Measured at each tap' : liveVal != null ? `${liveVal} dBm` : 'No reading'}
            {liveQ != null && <Text style={{ color: qualityColor(liveQ), fontSize: 15 }}>  {qualityLabel(liveQ)}</Text>}
          </Text>
        </View>
      </Card>

      <View style={{ flexDirection: 'row', marginBottom: 12 }}>
        {(['wifi', 'cell', 'down'] as HeatMetric[]).map((m) => (
          <Chip key={m} label={METRIC_LABEL[m]} active={metric === m} onPress={() => setMetric(m)} />
        ))}
      </View>

      {/* the map */}
      <View
        style={{ width: W, height: H, borderRadius: 16, overflow: 'hidden', backgroundColor: C.cardHi, borderWidth: 1, borderColor: C.border }}
        onStartShouldSetResponder={() => true}
        onResponderRelease={onTap}
      >
        {map.background.type === 'photo' ? (
          <View pointerEvents="none">
            <Image source={{ uri: map.background.uri }} style={{ width: W, height: H }} contentFit="fill" />
          </View>
        ) : null}
        <Svg width={W} height={H} style={{ position: 'absolute', left: 0, top: 0 }} pointerEvents="none">
          {map.background.type === 'grid' && (
            <G>
              {Array.from({ length: 13 }, (_, i) => (
                <Line key={`v${i}`} x1={(W * i) / 12} y1={0} x2={(W * i) / 12} y2={H} stroke={C.border} strokeWidth={1} />
              ))}
              {Array.from({ length: Math.round(12 / aspect) + 1 }, (_, i) => (
                <Line key={`h${i}`} x1={0} y1={(H * i) / Math.round(12 / aspect)} x2={W} y2={(H * i) / Math.round(12 / aspect)} stroke={C.border} strokeWidth={1} />
              ))}
            </G>
          )}
          {heatRects}
          {map.points.map((p) => {
            const q = pointQuality(p, metric);
            const v = pointValue(p, metric);
            const isBest = stats && stats.count > 2 && stats.best.p.id === p.id;
            return (
              <G key={p.id}>
                <Circle cx={p.x * W} cy={p.y * H} r={isBest ? 11 : 8} fill={qualityColor(q)} stroke={isBest ? '#fff' : '#0008'} strokeWidth={isBest ? 3 : 2} />
                {v != null && (
                  <G>
                    <SvgText x={p.x * W + 1} y={p.y * H - 12} fill="#000" fillOpacity={0.8} fontSize={12} fontWeight="bold" textAnchor="middle">
                      {metric === 'down' ? `${Math.round(v)}` : `${v}`}
                    </SvgText>
                    <SvgText x={p.x * W} y={p.y * H - 13} fill="#fff" fontSize={12} fontWeight="bold" textAnchor="middle">
                      {metric === 'down' ? `${Math.round(v)}` : `${v}`}
                    </SvgText>
                  </G>
                )}
              </G>
            );
          })}
          {pending && <Circle cx={pending.x * W} cy={pending.y * H} r={14} fill="none" stroke="#fff" strokeWidth={3} strokeDasharray="5,4" />}
        </Svg>
        {pending && (
          <View pointerEvents="none" style={{ position: 'absolute', bottom: 10, alignSelf: 'center', backgroundColor: 'rgba(0,0,0,0.7)', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999, flexDirection: 'row', alignItems: 'center' }}>
            <ActivityIndicator color="#fff" size="small" />
            <Text style={{ color: '#fff', marginLeft: 8, fontWeight: '600' }}>{pending.stage}</Text>
          </View>
        )}
      </View>

      <Text style={[styles.dim, { textAlign: 'center', marginVertical: 10 }]}>
        {map.points.length === 0
          ? 'Stand somewhere in the space, then tap that spot on the picture.'
          : 'Move a few steps and tap again. 8–15 spread-out readings make a good map.'}
      </Text>

      {/* legend */}
      <View style={{ flexDirection: 'row', height: 10, borderRadius: 5, overflow: 'hidden', marginBottom: 4 }}>
        {Array.from({ length: 20 }, (_, i) => (
          <View key={i} style={{ flex: 1, backgroundColor: qualityColor((i / 19) * 100) }} />
        ))}
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 16 }}>
        <Text style={styles.dim}>{metric === 'wifi' ? '−90 dBm' : metric === 'cell' ? '−120 dBm' : '1 Mbps'}</Text>
        <Text style={styles.dim}>{metric === 'wifi' ? '−40 dBm' : metric === 'cell' ? '−65 dBm' : '300+ Mbps'}</Text>
      </View>

      <View style={{ flexDirection: 'row', gap: 10, marginBottom: 14 }}>
        <Button title="Undo" kind="ghost" onPress={undo} disabled={!map.points.length || !!pending} style={{ flex: 1 }} />
        <Button title="Clear" kind="danger" onPress={clear} disabled={!map.points.length || !!pending} style={{ flex: 1 }} />
      </View>

      <Card>
        <Row label="Show heatmap" value={<Switch value={showHeat} onValueChange={setShowHeat} />} />
        <Row label="Also test speed at each spot (~3 s)" value={<Switch value={withSpeed} onValueChange={setWithSpeed} />} />
        <View style={{ paddingTop: 10 }}>
          <Text style={styles.dim}>Map name</Text>
          <TextInput
            defaultValue={map.name}
            onEndEditing={(e) => e.nativeEvent.text.trim() && update({ ...map, name: e.nativeEvent.text.trim() })}
            style={{ color: C.text, fontSize: 16, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: C.border }}
            placeholderTextColor={C.dim}
          />
        </View>
      </Card>

      {stats && (
        <Card>
          <Text style={styles.h2}>{METRIC_LABEL[metric]} summary</Text>
          <Row label="Readings" value={`${stats.count}`} />
          <Row label="Best spot (white ring)" value={formatValue(stats.best.v, metric)} />
          <Row label="Worst spot" value={formatValue(stats.worst.v, metric)} />
          <Row label="Average" value={formatValue(stats.avg, metric)} />
          {metric === 'wifi' && stats.worst.v < -75 && (
            <Text style={[styles.dim, { marginTop: 10, lineHeight: 19 }]}>
              Some areas drop below −75 dBm. Moving the router toward the weak area, raising it off the floor, or adding a mesh node near the dead zone usually helps.
            </Text>
          )}
        </Card>
      )}
    </ScrollView>
  );
}
