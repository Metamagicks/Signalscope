import { Tabs } from 'expo-router/tabs';
import { MapIcon, SignalIcon, SpeedIcon } from '../../components/icons';
import { C } from '../../lib/theme';

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerStyle: { backgroundColor: C.bg },
        headerTintColor: C.text,
        headerTitleStyle: { fontWeight: '800' },
        headerShadowVisible: false,
        tabBarStyle: { backgroundColor: C.card, borderTopColor: C.border },
        tabBarActiveTintColor: C.accent,
        tabBarInactiveTintColor: C.dim,
        sceneStyle: { backgroundColor: C.bg },
      }}
    >
      <Tabs.Screen name="index" options={{ title: 'Signal', tabBarIcon: ({ color }) => <SignalIcon color={String(color)} /> }} />
      <Tabs.Screen name="speed" options={{ title: 'Speed test', tabBarIcon: ({ color }) => <SpeedIcon color={String(color)} /> }} />
      <Tabs.Screen name="maps" options={{ title: 'Signal maps', tabBarIcon: ({ color }) => <MapIcon color={String(color)} /> }} />
    </Tabs>
  );
}
