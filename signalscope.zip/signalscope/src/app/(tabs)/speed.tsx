import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { useEffect, useRef, useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { Button, Card, Gauge, Row, styles } from '../../components/ui';
import { useSignal } from '../../lib/signal';
import { formatMbps, runSpeedTest, SpeedProgress } from '../../lib/speedtest';
import { C } from '../../lib/theme';

type HistoryItem = { t: number; transport: string; name?: string | null; ping?: number; down?: number; up?: number };
const HKEY = 'signalscope:speed-history:v1';

// gauge scale: log, 1 → 1000 Mbps
const gaugeFrac = (m?: number) => (m == null || m <= 0 ? 0 : Math.min(1, Math.log10(1 + m) / 3));

export default function SpeedScreen() {
  const { current } = useSignal();
  const [p, setP] = useState<SpeedProgress>({ phase: 'idle' });
  const [hist, setHist] = useState<HistoryItem[]>([]);
  const abort = useRef<AbortController | null>(null);
  const running = ['ping', 'download', 'upload'].includes(p.phase);

  useEffect(() => {
    AsyncStorage.getItem(HKEY).then((r) => r && setHist(JSON.parse(r))).catch(() => {});
    return () => abort.current?.abort();
  }, []);

  const start = async () => {
    abort.current = new AbortController();
    const res = await runSpeedTest(setP, abort.current.signal);
    if (res.phase === 'done') {
      const item: HistoryItem = {
        t: Date.now(),
        transport: current?.transport ?? 'unknown',
        name: current?.transport === 'wifi' ? current.wifi?.ssid : current?.cell?.carrier,
        ping: res.pingMs,
        down: res.downloadMbps,
        up: res.uploadMbps,
      };
      const next = [item, ...hist].slice(0, 25);
      setHist(next);
      AsyncStorage.setItem(HKEY, JSON.stringify(next)).catch(() => {});
    }
  };

  const centerValue =
    p.phase === 'download' || p.phase === 'upload' ? p.liveMbps : p.phase === 'done' ? p.downloadMbps : undefined;
  const color = p.phase === 'upload' ? C.accent2 : C.accent;
  const phaseLabel: Record<string, string> = {
    idle: 'Ready', ping: 'Measuring latency…', download: 'Download', upload: 'Upload', done: 'Download', error: p.error ?? 'Error',
  };

  return (
    <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <Card style={{ alignItems: 'center', paddingVertical: 22 }}>
        <Text style={[styles.dim, { marginBottom: 10 }]}>
          {current?.transport === 'wifi'
            ? `Testing over Wi-Fi${current.wifi?.ssid ? ` · ${current.wifi.ssid}` : ''}`
            : current?.transport === 'cellular'
            ? `Testing over mobile data${current.cell?.carrier ? ` · ${current.cell.carrier}` : ''}`
            : 'Speed test'}
        </Text>
        <Gauge value={gaugeFrac(centerValue)} color={color} size={240}>
          <Text style={{ color: C.text, fontSize: 48, fontWeight: '800' }}>{formatMbps(centerValue)}</Text>
          <Text style={{ color: C.dim, fontSize: 14 }}>Mbps</Text>
          <Text style={{ color: p.phase === 'error' ? C.danger : color, fontWeight: '700', marginTop: 6 }}>{phaseLabel[p.phase]}</Text>
        </Gauge>

        <View style={{ flexDirection: 'row', width: '100%', marginTop: 14 }}>
          {[
            { k: 'Ping', v: p.pingMs != null ? `${p.pingMs} ms` : '—' },
            { k: 'Jitter', v: p.jitterMs != null ? `${p.jitterMs} ms` : '—' },
            { k: 'Down', v: p.downloadMbps != null ? formatMbps(p.downloadMbps) : '—' },
            { k: 'Up', v: p.uploadMbps != null ? formatMbps(p.uploadMbps) : '—' },
          ].map((x) => (
            <View key={x.k} style={{ flex: 1, alignItems: 'center' }}>
              <Text style={styles.dim}>{x.k}</Text>
              <Text style={{ color: C.text, fontSize: 17, fontWeight: '700', marginTop: 2 }}>{x.v}</Text>
            </View>
          ))}
        </View>

        <Button
          title={running ? 'Cancel' : p.phase === 'idle' ? 'Start test' : 'Run again'}
          kind={running ? 'ghost' : 'primary'}
          onPress={running ? () => abort.current?.abort() : start}
          style={{ marginTop: 18, alignSelf: 'stretch' }}
        />
        <Text style={[styles.dim, { marginTop: 10, fontSize: 11 }]}>
          Uses Cloudflare's speed servers. A full test uses roughly 50–500 MB on fast connections.
        </Text>
      </Card>

      {hist.length > 0 && (
        <Card>
          <Text style={styles.h2}>History</Text>
          {hist.map((h) => (
            <Row
              key={h.t}
              label={`${new Date(h.t).toLocaleDateString()} ${new Date(h.t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} · ${h.transport === 'wifi' ? 'Wi-Fi' : h.transport === 'cellular' ? 'Mobile' : h.transport}`}
              value={`↓${formatMbps(h.down)}  ↑${formatMbps(h.up)}  ${h.ping ?? '—'}ms`}
            />
          ))}
        </Card>
      )}
    </ScrollView>
  );
}
