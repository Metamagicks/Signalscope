import { Image } from 'expo-image';
import { router, useFocusEffect } from 'expo-router';
import React, { useCallback, useState } from 'react';
import { Alert, FlatList, Pressable, Text, View } from 'react-native';
import { Button, Card, styles } from '../../components/ui';
import { summarize } from '../../lib/heatmap';
import { deleteMap, listMaps, SignalMap } from '../../lib/maps';
import { C } from '../../lib/theme';

export default function MapsScreen() {
  const [maps, setMaps] = useState<SignalMap[]>([]);

  useFocusEffect(
    useCallback(() => {
      listMaps().then(setMaps);
    }, [])
  );

  const confirmDelete = (m: SignalMap) =>
    Alert.alert('Delete map?', `"${m.name}" and its ${m.points.length} readings will be removed.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => { await deleteMap(m.id); setMaps(await listMaps()); } },
    ]);

  return (
    <FlatList
      data={maps}
      keyExtractor={(m) => m.id}
      contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
      ListHeaderComponent={
        <Card>
          <Text style={styles.h2}>Map the signal in a room or yard</Text>
          <Text style={[styles.dim, { marginBottom: 14, lineHeight: 19 }]}>
            1. Snap a photo of the space with your camera (or use a blank grid).{'\n'}
            2. Walk to a spot and tap where you're standing on the photo.{'\n'}
            3. The app measures signal there. Repeat — a heatmap fills in.
          </Text>
          <Button title="New signal map" onPress={() => router.push('/map/new')} />
        </Card>
      }
      ListEmptyComponent={<Text style={[styles.dim, { textAlign: 'center', marginTop: 20 }]}>No maps yet.</Text>}
      renderItem={({ item: m }) => {
        const w = summarize(m.points, 'wifi');
        return (
          <Pressable onPress={() => router.push(`/map/${m.id}`)} onLongPress={() => confirmDelete(m)}>
            <Card style={{ flexDirection: 'row', alignItems: 'center', padding: 10 }}>
              {m.background.type === 'photo' ? (
                <Image source={{ uri: m.background.uri }} style={{ width: 72, height: 72, borderRadius: 12 }} contentFit="cover" />
              ) : (
                <View style={{ width: 72, height: 72, borderRadius: 12, backgroundColor: C.cardHi, alignItems: 'center', justifyContent: 'center' }}>
                  <Text style={{ color: C.dim, fontSize: 26 }}>#</Text>
                </View>
              )}
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={{ color: C.text, fontSize: 16, fontWeight: '700' }} numberOfLines={1}>{m.name}</Text>
                <Text style={styles.dim}>
                  {m.points.length} readings · {new Date(m.updatedAt).toLocaleDateString()}
                </Text>
                {w && <Text style={styles.dim}>Wi-Fi {w.worst.v} to {w.best.v} dBm</Text>}
              </View>
              <Text style={{ color: C.dim, fontSize: 22 }}>›</Text>
            </Card>
          </Pressable>
        );
      }}
      ListFooterComponent={maps.length ? <Text style={[styles.dim, { textAlign: 'center' }]}>Long-press a map to delete it.</Text> : undefined}
    />
  );
}
