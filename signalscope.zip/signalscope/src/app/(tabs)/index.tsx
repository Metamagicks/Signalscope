import React from 'react';
import { ScrollView, Text, useWindowDimensions, View } from 'react-native';
import { Bars, Card, Gauge, Row, Sparkline, styles } from '../../components/ui';
import { cellQuality, qualityColor, qualityLabel, useSignal, wifiQuality } from '../../lib/signal';
import { C } from '../../lib/theme';

const band = (mhz?: number) => (!mhz ? '—' : mhz >= 5925 ? '6 GHz' : mhz >= 4900 ? '5 GHz' : '2.4 GHz');

export default function SignalScreen() {
  const { current: s, history } = useSignal();
  const { width } = useWindowDimensions();

  const transportLabel =
    !s ? 'Checking…' : s.transport === 'wifi' ? 'Wi-Fi' : s.transport === 'cellular' ? 'Mobile data' : s.transport === 'none' ? 'Offline' : s.transport;

  const wifiHist = history.map((h) => h.wifi?.rssi ?? null);
  const cellHist = history.map((h) => h.cell?.dbm ?? null);
  const wifiQ = s?.wifi?.rssi != null ? wifiQuality(s.wifi.rssi) : null;
  const cellQ = s?.cell?.dbm != null ? cellQuality(s.cell.dbm) : null;

  return (
    <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
      <Card style={{ alignItems: 'center', paddingVertical: 22 }}>
        <Text style={[styles.dim, { marginBottom: 4 }]}>ACTIVE CONNECTION</Text>
        <Text style={[styles.h1, { marginBottom: 10 }]}>{transportLabel}</Text>
        <Gauge value={s?.quality != null ? s.quality / 100 : null}>
          <Text style={{ color: C.text, fontSize: 46, fontWeight: '800' }}>{s?.dbm ?? (s?.quality != null ? s.quality : '—')}</Text>
          <Text style={{ color: C.dim, fontSize: 14 }}>{s?.dbm != null ? 'dBm' : s?.quality != null ? 'score' : ''}</Text>
          <Text style={{ color: qualityColor(s?.quality ?? null), fontSize: 16, fontWeight: '700', marginTop: 6 }}>
            {qualityLabel(s?.quality ?? null)}
          </Text>
        </Gauge>
        {s && !s.native && (
          <Text style={[styles.dim, { textAlign: 'center', marginTop: 8 }]}>
            Running without the native signal module (e.g. Expo Go). Install a development build to see real dBm readings.
          </Text>
        )}
      </Card>

      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text style={styles.h2}>Wi-Fi</Text>
          <Bars level={s?.wifi?.level ?? null} />
        </View>
        {s?.wifi?.connected ? (
          <>
            <Sparkline values={wifiHist} width={width - 66} min={-95} max={-25} color={qualityColor(wifiQ)} />
            <Row label="Network" value={s.wifi.ssid ?? 'Hidden (allow location to see name)'} />
            <Row label="Signal" value={`${s.wifi.rssi} dBm · ${qualityLabel(wifiQ)}`} />
            <Row label="Link speed" value={`${s.wifi.linkSpeedMbps ?? '—'} Mbps`} />
            {s.wifi.rxLinkSpeedMbps != null && (
              <Row label="Rx / Tx link" value={`${s.wifi.rxLinkSpeedMbps} / ${s.wifi.txLinkSpeedMbps} Mbps`} />
            )}
            <Row label="Band" value={`${band(s.wifi.frequencyMHz)} (${s.wifi.frequencyMHz ?? '—'} MHz)`} />
            {s.wifi.wifiStandard && <Row label="Standard" value={s.wifi.wifiStandard} />}
          </>
        ) : (
          <Text style={styles.dim}>
            {s?.wifi == null ? (s?.netinfo?.type === 'wifi' ? `Connected (strength ${s.quality ?? '—'}/100)` : 'Not connected') : s.wifi.enabled ? 'Wi-Fi on, not connected' : 'Wi-Fi is off'}
          </Text>
        )}
      </Card>

      <Card>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Text style={styles.h2}>Mobile network</Text>
          <Bars level={s?.cell?.level ?? null} />
        </View>
        {s?.cell?.available ? (
          <>
            <Sparkline values={cellHist} width={width - 66} min={-125} max={-65} color={qualityColor(cellQ)} />
            <Row label="Carrier" value={s.cell.carrier ?? '—'} />
            <Row label="Signal" value={s.cell.dbm != null ? `${s.cell.dbm} dBm · ${qualityLabel(cellQ)}` : `Level ${s.cell.level ?? '—'}/4`} />
            <Row label="Technology" value={s.cell.technology ?? '—'} />
            {s.cell.networkType && <Row label="Data network" value={s.cell.networkType} />}
            {s.cell.rsrp != null && <Row label="RSRP" value={`${s.cell.rsrp} dBm`} />}
            {s.cell.rsrq != null && <Row label="RSRQ" value={`${s.cell.rsrq} dB`} />}
            {s.cell.rssnr != null && <Row label="SNR" value={`${s.cell.rssnr} dB`} />}
          </>
        ) : (
          <Text style={styles.dim}>
            {s?.cell?.reason ?? (s?.netinfo?.type === 'cellular' ? `Connected (${(s.netinfo.details as any)?.cellularGeneration ?? 'cellular'})` : 'No cellular info')}
          </Text>
        )}
      </Card>

      <Text style={[styles.dim, { textAlign: 'center' }]}>
        Wi-Fi: −30 to −60 dBm great · −67 good for streaming · below −80 weak{'\n'}Cell: above −85 dBm great · −100 fair · below −110 weak
      </Text>
    </ScrollView>
  );
}
