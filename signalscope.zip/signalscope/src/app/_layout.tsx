import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SignalProvider } from '../lib/signal';
import { C } from '../lib/theme';

export default function RootLayout() {
  return (
    <SignalProvider>
      <StatusBar style="light" />
      <Stack
        screenOptions={{
          headerStyle: { backgroundColor: C.bg },
          headerTintColor: C.text,
          headerTitleStyle: { fontWeight: '700' },
          contentStyle: { backgroundColor: C.bg },
        }}
      >
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="map/new" options={{ title: 'New signal map', headerShown: false }} />
        <Stack.Screen name="map/[id]" options={{ title: 'Signal map' }} />
      </Stack>
    </SignalProvider>
  );
}
