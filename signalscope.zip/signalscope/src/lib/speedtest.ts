/**
 * Speed test against Cloudflare's public speed endpoints (the same ones used by speed.cloudflare.com).
 * Uses XMLHttpRequest so we get live progress for download and upload.
 */
const BASE = 'https://speed.cloudflare.com';

export type SpeedPhase = 'idle' | 'ping' | 'download' | 'upload' | 'done' | 'error';

export type SpeedProgress = {
  phase: SpeedPhase;
  /** Live Mbps for the current phase. */
  liveMbps?: number;
  pingMs?: number;
  jitterMs?: number;
  downloadMbps?: number;
  uploadMbps?: number;
  /** 0–1 progress of the current phase. */
  progress?: number;
  error?: string;
};

const now = () => (typeof performance !== "undefined" ? performance.now() : Date.now());
const mbps = (bytes: number, ms: number) => (ms > 0 ? (bytes * 8) / (ms / 1000) / 1e6 : 0);

function xhr(
  method: 'GET' | 'POST',
  url: string,
  opts: { body?: string; onProgress?: (loaded: number) => void; timeoutMs?: number; signal?: AbortSignal } = {}
): Promise<number> {
  return new Promise((resolve, reject) => {
    if (opts.signal?.aborted) return reject(new Error('aborted'));
    const req = new XMLHttpRequest();
    req.open(method, url);
    // 'blob' keeps the downloaded bytes on the native side. With the default 'text' type, Android
    // decodes every 8 KB chunk into a string and ships it to JS, which caps the measured speed and
    // can run out of memory on large chunks.
    if (method === 'GET') req.responseType = 'blob';
    req.timeout = opts.timeoutMs ?? 15000;
    req.setRequestHeader('Cache-Control', 'no-store');
    if (method === 'POST') req.setRequestHeader('Content-Type', 'text/plain');
    if (opts.onProgress) {
      if (method === 'GET') req.onprogress = (e) => opts.onProgress!(e.loaded);
      else if (req.upload) req.upload.onprogress = (e) => opts.onProgress!(e.loaded);
    }
    const onAbort = () => {
      req.abort();
      reject(new Error('aborted'));
    };
    const done = () => {
      opts.signal?.removeEventListener('abort', onAbort);
      // free the native blob straight away
      try { (req.response as any)?.close?.(); } catch {}
    };
    req.onload = () => {
      done();
      req.status >= 200 && req.status < 400 ? resolve(req.status) : reject(new Error(`HTTP ${req.status}`));
    };
    req.onerror = () => { done(); reject(new Error('Network error')); };
    req.ontimeout = () => { done(); resolve(-1); }; // a timeout mid-transfer still gives us usable bytes
    opts.signal?.addEventListener('abort', onAbort);
    req.send(opts.body ?? null);
  });
}

export async function measurePing(samples = 8, signal?: AbortSignal) {
  const times: number[] = [];
  for (let i = 0; i < samples; i++) {
    if (signal?.aborted) throw new Error('aborted');
    const t0 = now();
    const status = await xhr('GET', `${BASE}/__down?bytes=0&r=${Math.random()}`, { timeoutMs: 5000, signal });
    if (status > 0) times.push(now() - t0);
  }
  if (!times.length) throw new Error('Server not reachable');
  // first request includes the TLS handshake — drop it
  const t = times.length > 2 ? times.slice(1) : times;
  const sorted = [...t].sort((a, b) => a - b);
  const ping = sorted[Math.floor(sorted.length / 2)];
  let jitter = 0;
  for (let i = 1; i < t.length; i++) jitter += Math.abs(t[i] - t[i - 1]);
  jitter = t.length > 1 ? jitter / (t.length - 1) : 0;
  return { pingMs: Math.round(ping), jitterMs: Math.round(jitter) };
}

/**
 * Runs `streams` parallel connections, each fetching (or sending) chunks back to back until the
 * deadline, growing the chunk size while there is time. Parallel streams are what real speed tests
 * use: a single TCP connection usually can't fill a fast link.
 */
async function measureTransfer(
  kind: 'down' | 'up',
  durationMs: number,
  streams: number,
  onLive?: (mbps: number, progress: number) => void,
  signal?: AbortSignal
) {
  const start = now();
  let total = 0;
  const report = () => {
    const el = now() - start;
    onLive?.(mbps(total, el), Math.min(1, el / durationMs));
  };

  const worker = async () => {
    let chunk = kind === 'down' ? 1_000_000 : 250_000;
    const maxChunk = kind === 'down' ? 50_000_000 : 8_000_000;
    while (now() - start < durationMs) {
      if (signal?.aborted) throw new Error('aborted');
      let lastLoaded = 0;
      const remaining = durationMs - (now() - start);
      const onProgress = (loaded: number) => {
        total += loaded - lastLoaded;
        lastLoaded = loaded;
        report();
      };
      const opts = { signal, timeoutMs: Math.max(1500, remaining + 500), onProgress };
      let status: number;
      try {
        status =
          kind === 'down'
            ? await xhr('GET', `${BASE}/__down?bytes=${chunk}&r=${Math.random()}`, opts)
            : await xhr('POST', `${BASE}/__up?r=${Math.random()}`, { ...opts, body: payload(chunk) });
      } catch (e: any) {
        if (e?.message === 'aborted') throw e;
        failures++;
        return; // this stream gives up; the others keep going
      }
      // If no progress events arrived, count the whole chunk once it completed
      if (status > 0 && lastLoaded < chunk) total += chunk - lastLoaded;
      report();
      if (now() - start < durationMs / 3) chunk = Math.min(chunk * 2, maxChunk);
    }
  };

  let failures = 0;
  await Promise.all(Array.from({ length: streams }, worker));
  if (failures === streams && total === 0) throw new Error('Network error');
  return mbps(total, now() - start);
}

const payloadCache: Record<number, string> = {};
const payload = (size: number) => (payloadCache[size] ??= '0'.repeat(size));

export const measureDownload = (durationMs = 8000, onLive?: (mbps: number, progress: number) => void, signal?: AbortSignal, streams = 4) =>
  measureTransfer('down', durationMs, streams, onLive, signal);

export const measureUpload = (durationMs = 7000, onLive?: (mbps: number, progress: number) => void, signal?: AbortSignal, streams = 3) =>
  measureTransfer('up', durationMs, streams, onLive, signal);

export async function runSpeedTest(onUpdate: (p: SpeedProgress) => void, signal?: AbortSignal): Promise<SpeedProgress> {
  const result: SpeedProgress = { phase: 'ping' };
  try {
    onUpdate({ ...result });
    Object.assign(result, await measurePing(8, signal));
    result.phase = 'download';
    onUpdate({ ...result, progress: 0 });
    result.downloadMbps = await measureDownload(8000, (m, p) => onUpdate({ ...result, liveMbps: m, progress: p }), signal);
    result.phase = 'upload';
    onUpdate({ ...result, progress: 0, liveMbps: 0 });
    result.uploadMbps = await measureUpload(7000, (m, p) => onUpdate({ ...result, liveMbps: m, progress: p }), signal);
    result.phase = 'done';
    onUpdate({ ...result });
    return result;
  } catch (e: any) {
    const r = { ...result, phase: 'error' as const, error: e?.message === 'aborted' ? 'Cancelled' : e?.message ?? 'Failed' };
    onUpdate(r);
    return r;
  }
}

/** Short (~2.5s) download probe used when sampling points on a signal map. */
export async function quickDownloadProbe(signal?: AbortSignal) {
  try {
    return Math.round((await measureDownload(2500, undefined, signal, 2)) * 10) / 10;
  } catch {
    return null;
  }
}

export const formatMbps = (v?: number | null) =>
  v == null ? '—' : v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2);
