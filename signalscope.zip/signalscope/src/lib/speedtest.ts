/**
 * Speed test against Cloudflare's public speed endpoints (the same ones used by speed.cloudflare.com).
 * Uses XMLHttpRequest so we get live progress for download and upload.
 */
const BASE = 'https://speed.cloudflare.com';

export type SpeedPhase = 'idle' | 'ping' | 'download' | 'upload' | 'done' | 'error';

export type SpeedProgress = {
  phase: SpeedPhase;
  /** Live Mbps for the current phase. */
  liveMbps?: number;
  pingMs?: number;
  jitterMs?: number;
  downloadMbps?: number;
  uploadMbps?: number;
  /** 0–1 progress of the current phase. */
  progress?: number;
  error?: string;
};

const now = () => (typeof performance !== "undefined" ? performance.now() : Date.now());
const mbps = (bytes: number, ms: number) => (ms > 0 ? (bytes * 8) / (ms / 1000) / 1e6 : 0);

function xhr(
  method: 'GET' | 'POST',
  url: string,
  opts: { body?: string; onProgress?: (loaded: number) => void; timeoutMs?: number; signal?: AbortSignal } = {}
): Promise<number> {
  return new Promise((resolve, reject) => {
    const req = new XMLHttpRequest();
    req.open(method, url);
    req.timeout = opts.timeoutMs ?? 15000;
    req.setRequestHeader('Cache-Control', 'no-store');
    if (method === 'POST') req.setRequestHeader('Content-Type', 'text/plain');
    if (opts.onProgress) {
      if (method === 'GET') req.onprogress = (e) => opts.onProgress!(e.loaded);
      else if (req.upload) req.upload.onprogress = (e) => opts.onProgress!(e.loaded);
    }
    req.onload = () => (req.status >= 200 && req.status < 400 ? resolve(req.status) : reject(new Error(`HTTP ${req.status}`)));
    req.onerror = () => reject(new Error('Network error'));
    req.ontimeout = () => resolve(-1); // a timeout mid-transfer still gives us usable bytes
    opts.signal?.addEventListener('abort', () => {
      req.abort();
      reject(new Error('aborted'));
    });
    req.send(opts.body ?? null);
  });
}

export async function measurePing(samples = 8, signal?: AbortSignal) {
  const times: number[] = [];
  for (let i = 0; i < samples; i++) {
    if (signal?.aborted) throw new Error('aborted');
    const t0 = now();
    await xhr('GET', `${BASE}/__down?bytes=0&r=${Math.random()}`, { timeoutMs: 5000, signal });
    times.push(now() - t0);
  }
  // first request includes TLS handshake — drop it
  const t = times.length > 2 ? times.slice(1) : times;
  const sorted = [...t].sort((a, b) => a - b);
  const ping = sorted[Math.floor(sorted.length / 2)];
  let jitter = 0;
  for (let i = 1; i < t.length; i++) jitter += Math.abs(t[i] - t[i - 1]);
  jitter = t.length > 1 ? jitter / (t.length - 1) : 0;
  return { pingMs: Math.round(ping), jitterMs: Math.round(jitter) };
}

/**
 * Downloads chunks repeatedly for `durationMs`, growing chunk size as speed allows.
 * Returns Mbps. `onLive` is called with a rolling speed.
 */
export async function measureDownload(durationMs = 8000, onLive?: (mbps: number, progress: number) => void, signal?: AbortSignal) {
  const start = now();
  let total = 0;
  let chunk = 1_000_000;
  while (now() - start < durationMs) {
    if (signal?.aborted) throw new Error('aborted');
    let lastLoaded = 0;
    const remaining = durationMs - (now() - start);
    const status = await xhr('GET', `${BASE}/__down?bytes=${chunk}&r=${Math.random()}`, {
      timeoutMs: Math.max(1500, remaining + 500),
      signal,
      onProgress: (loaded) => {
        total += loaded - lastLoaded;
        lastLoaded = loaded;
        const el = now() - start;
        onLive?.(mbps(total, el), Math.min(1, el / durationMs));
      },
    });
    // If onprogress was not delivered, count the whole chunk
    if (lastLoaded === 0 && status > 0) total += chunk;
    const el = now() - start;
    onLive?.(mbps(total, el), Math.min(1, el / durationMs));
    if (el < durationMs / 3) chunk = Math.min(chunk * 2, 50_000_000);
  }
  return mbps(total, now() - start);
}

const payloadCache: Record<number, string> = {};
const payload = (size: number) => (payloadCache[size] ??= '0'.repeat(size));

export async function measureUpload(durationMs = 7000, onLive?: (mbps: number, progress: number) => void, signal?: AbortSignal) {
  const start = now();
  let total = 0;
  let chunk = 500_000;
  while (now() - start < durationMs) {
    if (signal?.aborted) throw new Error('aborted');
    let lastLoaded = 0;
    const remaining = durationMs - (now() - start);
    const body = payload(chunk);
    const status = await xhr('POST', `${BASE}/__up?r=${Math.random()}`, {
      body,
      signal,
      timeoutMs: Math.max(1500, remaining + 500),
      onProgress: (loaded) => {
        total += loaded - lastLoaded;
        lastLoaded = loaded;
        const el = now() - start;
        onLive?.(mbps(total, el), Math.min(1, el / durationMs));
      },
    });
    if (lastLoaded === 0 && status > 0) total += chunk;
    const el = now() - start;
    onLive?.(mbps(total, el), Math.min(1, el / durationMs));
    if (el < durationMs / 3) chunk = Math.min(chunk * 2, 8_000_000);
  }
  return mbps(total, now() - start);
}

export async function runSpeedTest(onUpdate: (p: SpeedProgress) => void, signal?: AbortSignal): Promise<SpeedProgress> {
  const result: SpeedProgress = { phase: 'ping' };
  try {
    onUpdate({ ...result });
    Object.assign(result, await measurePing(8, signal));
    result.phase = 'download';
    onUpdate({ ...result, progress: 0 });
    result.downloadMbps = await measureDownload(8000, (m, p) => onUpdate({ ...result, liveMbps: m, progress: p }), signal);
    result.phase = 'upload';
    onUpdate({ ...result, progress: 0, liveMbps: 0 });
    result.uploadMbps = await measureUpload(7000, (m, p) => onUpdate({ ...result, liveMbps: m, progress: p }), signal);
    result.phase = 'done';
    onUpdate({ ...result });
    return result;
  } catch (e: any) {
    const r = { ...result, phase: 'error' as const, error: e?.message === 'aborted' ? 'Cancelled' : e?.message ?? 'Failed' };
    onUpdate(r);
    return r;
  }
}

/** Short (~2.5s) download probe used when sampling points on a signal map. */
export async function quickDownloadProbe(signal?: AbortSignal) {
  try {
    return Math.round((await measureDownload(2500, undefined, signal)) * 10) / 10;
  } catch {
    return null;
  }
}

export const formatMbps = (v?: number | null) =>
  v == null ? '—' : v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2);
