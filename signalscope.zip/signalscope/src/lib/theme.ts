export const C = {
  bg: '#0b1020',
  card: '#141a2e',
  cardHi: '#1c2440',
  border: '#26304f',
  text: '#e8ecf8',
  dim: '#8a94b3',
  accent: '#22d3ee',
  accent2: '#a78bfa',
  danger: '#f87171',
};
