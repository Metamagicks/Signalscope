import { cellQuality, wifiQuality } from './signal';
import type { MapPoint } from './maps';

export type HeatMetric = 'wifi' | 'cell' | 'down';

export const METRIC_LABEL: Record<HeatMetric, string> = {
  wifi: 'Wi-Fi signal',
  cell: 'Cell signal',
  down: 'Download',
};

/** Download speed → 0–100 on a log scale (1 Mbps ≈ 0, 300+ Mbps ≈ 100). */
export const speedQuality = (mbps: number) =>
  Math.round(Math.max(0, Math.min(100, (Math.log10(Math.max(mbps, 1)) / Math.log10(300)) * 100)));

export function pointValue(p: MapPoint, metric: HeatMetric): number | null {
  if (metric === 'wifi') return p.wifi;
  if (metric === 'cell') return p.cell;
  return p.down;
}

export function pointQuality(p: MapPoint, metric: HeatMetric): number | null {
  const v = pointValue(p, metric);
  if (v == null) return null;
  if (metric === 'wifi') return wifiQuality(v);
  if (metric === 'cell') return cellQuality(v);
  return speedQuality(v);
}

export type HeatCell = { col: number; row: number; q: number; alpha: number };

/**
 * Inverse-distance-weighted interpolation over a grid.
 * `aspect` = width / height so distances are measured in real proportions.
 */
export function buildHeatGrid(points: MapPoint[], metric: HeatMetric, cols: number, rows: number, aspect: number, reach = 0.35): HeatCell[] {
  const samples = points
    .map((p) => ({ x: p.x * aspect, y: p.y, q: pointQuality(p, metric) }))
    .filter((s): s is { x: number; y: number; q: number } => s.q != null);
  if (!samples.length) return [];

  const cells: HeatCell[] = [];
  const reachScaled = reach * Math.sqrt(Math.max(aspect, 1));
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const cx = ((c + 0.5) / cols) * aspect;
      const cy = (r + 0.5) / rows;
      let num = 0;
      let den = 0;
      let dmin = Infinity;
      let exact: number | null = null;
      for (const s of samples) {
        const d = Math.hypot(s.x - cx, s.y - cy);
        if (d < 1e-6) { exact = s.q; dmin = 0; break; }
        const w = 1 / (d * d);
        num += w * s.q;
        den += w;
        if (d < dmin) dmin = d;
      }
      const q = exact ?? num / den;
      // Fade out where we have no nearby measurements
      const alpha = Math.max(0, 1 - dmin / reachScaled);
      if (alpha > 0.02) cells.push({ col: c, row: r, q, alpha });
    }
  }
  return cells;
}

export function summarize(points: MapPoint[], metric: HeatMetric) {
  const vals = points
    .map((p) => ({ p, v: pointValue(p, metric) }))
    .filter((x): x is { p: MapPoint; v: number } => x.v != null);
  if (!vals.length) return null;
  const best = vals.reduce((a, b) => (b.v > a.v ? b : a));
  const worst = vals.reduce((a, b) => (b.v < a.v ? b : a));
  const avg = vals.reduce((s, x) => s + x.v, 0) / vals.length;
  return { best, worst, avg, count: vals.length };
}

export function formatValue(v: number | null | undefined, metric: HeatMetric) {
  if (v == null) return '—';
  if (metric === 'down') return `${v >= 10 ? v.toFixed(0) : v.toFixed(1)} Mbps`;
  return `${Math.round(v)} dBm`;
}
