import AsyncStorage from '@react-native-async-storage/async-storage';
import { Directory, File, Paths } from 'expo-file-system';

export type MapPoint = {
  id: string;
  /** Normalised position on the background, 0–1. */
  x: number;
  y: number;
  wifi: number | null; // dBm
  cell: number | null; // dBm
  down: number | null; // Mbps
  ssid?: string | null;
  t: number;
};

export type MapBackground =
  | { type: 'photo'; uri: string; width: number; height: number }
  | { type: 'grid'; width: number; height: number };

export type SignalMap = {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  background: MapBackground;
  points: MapPoint[];
};

const KEY = 'signalscope:maps:v1';
export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

async function readAll(): Promise<SignalMap[]> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as SignalMap[]) : [];
  } catch {
    return [];
  }
}
async function writeAll(maps: SignalMap[]) {
  await AsyncStorage.setItem(KEY, JSON.stringify(maps));
}

export async function listMaps() {
  return (await readAll()).sort((a, b) => b.updatedAt - a.updatedAt);
}
export async function getMap(id: string) {
  return (await readAll()).find((m) => m.id === id) ?? null;
}
export async function saveMap(map: SignalMap) {
  const all = await readAll();
  const i = all.findIndex((m) => m.id === map.id);
  const next = { ...map, updatedAt: Date.now() };
  if (i >= 0) all[i] = next;
  else all.push(next);
  await writeAll(all);
  return next;
}
export async function deleteMap(id: string) {
  const all = await readAll();
  const m = all.find((x) => x.id === id);
  if (m?.background.type === 'photo') {
    try {
      const f = new File(m.background.uri);
      if (f.exists) f.delete();
    } catch {}
  }
  await writeAll(all.filter((x) => x.id !== id));
}

/** Copy a camera capture (cache) into permanent app storage. */
export function persistPhoto(tempUri: string, id: string): string {
  const dir = new Directory(Paths.document, 'maps');
  if (!dir.exists) dir.create({ intermediates: true });
  const dest = new File(dir, `${id}.jpg`);
  if (dest.exists) dest.delete();
  new File(tempUri).copySync(dest);
  return dest.uri;
}
