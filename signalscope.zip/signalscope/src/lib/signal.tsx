import NetInfo, { NetInfoState } from '@react-native-community/netinfo';
import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { PermissionsAndroid, Platform } from 'react-native';
import {
  CellReading,
  getActiveTransport,
  getCellInfo,
  getWifiInfo,
  isNativeAvailable,
  WifiReading,
} from '../../modules/signal-strength';

export type Transport = 'wifi' | 'cellular' | 'ethernet' | 'vpn' | 'none' | 'other' | 'unknown';

export type SignalSnapshot = {
  time: number;
  transport: Transport;
  connected: boolean;
  wifi: WifiReading | null;
  cell: CellReading | null;
  /** Signal strength of the active connection, in dBm (null if unknown). */
  dbm: number | null;
  /** 0–100 score for the active connection. */
  quality: number | null;
  /** True when values come from the real radio (native module) rather than estimates. */
  native: boolean;
  netinfo?: NetInfoState;
};

export type SignalMetric = 'wifi' | 'cell';

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

/** Piecewise-linear map from dBm to a 0–100 score through [dBm, score] breakpoints. */
function scale(dbm: number, pts: [number, number][]) {
  if (dbm <= pts[0][0]) return pts[0][1];
  for (let i = 1; i < pts.length; i++) {
    const [x1, y1] = pts[i];
    const [x0, y0] = pts[i - 1];
    if (dbm <= x1) return Math.round(y0 + ((dbm - x0) / (x1 - x0)) * (y1 - y0));
  }
  return pts[pts.length - 1][1];
}

/**
 * Wi-Fi RSSI. Score bands line up with the labels below:
 * ≥ −55 Excellent · −67 Good (the usual "reliable for video calls" bar) · −75 Fair · −82 Weak · −90 unusable.
 */
export const wifiQuality = (rssi: number) =>
  scale(rssi, [[-90, 0], [-82, 20], [-75, 40], [-67, 60], [-55, 80], [-40, 100]]);

/** Cellular dBm (LTE/5G RSRP-style): ≥ −80 Excellent · −90 Good · −100 Fair · −110 Weak · −120 no service. */
export const cellQuality = (dbm: number) =>
  scale(dbm, [[-120, 0], [-110, 20], [-100, 40], [-90, 60], [-80, 80], [-65, 100]]);

export function qualityFor(metric: SignalMetric, dbm: number) {
  return metric === 'wifi' ? wifiQuality(dbm) : cellQuality(dbm);
}

export function qualityLabel(q: number | null): string {
  if (q == null) return 'Unknown';
  if (q >= 80) return 'Excellent';
  if (q >= 60) return 'Good';
  if (q >= 40) return 'Fair';
  if (q >= 20) return 'Weak';
  return 'Very weak';
}

/** Red → orange → yellow → green → cyan for a 0–100 score. */
export function qualityColor(q: number | null): string {
  if (q == null) return '#6b7280';
  const stops: [number, [number, number, number]][] = [
    [0, [220, 38, 38]],
    [30, [249, 115, 22]],
    [55, [234, 179, 8]],
    [75, [34, 197, 94]],
    [100, [6, 182, 212]],
  ];
  for (let i = 1; i < stops.length; i++) {
    const [p1, c1] = stops[i];
    const [p0, c0] = stops[i - 1];
    if (q <= p1) {
      const t = (q - p0) / (p1 - p0);
      const c = c0.map((v, k) => Math.round(v + (c1[k] - v) * t));
      return `rgb(${c[0]},${c[1]},${c[2]})`;
    }
  }
  return 'rgb(6,182,212)';
}

async function requestRadioPermissions() {
  if (Platform.OS !== 'android') return;
  try {
    await PermissionsAndroid.requestMultiple([
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION,
      PermissionsAndroid.PERMISSIONS.READ_PHONE_STATE,
    ]);
  } catch {
    // user can still use the app; SSID / network type will be hidden
  }
}

/** Read everything once. Uses the native module when present, NetInfo otherwise. */
export async function readSignal(): Promise<SignalSnapshot> {
  const net = await NetInfo.fetch();
  const wifi = getWifiInfo();
  const cell = getCellInfo();
  const nativeTransport = getActiveTransport() as Transport | null;
  const transport: Transport = nativeTransport ?? ((net.type as Transport) || 'unknown');

  let dbm: number | null = null;
  let quality: number | null = null;

  if (transport === 'wifi') {
    if (wifi?.rssi != null) {
      dbm = wifi.rssi;
      quality = wifiQuality(wifi.rssi);
    } else if (net.type === 'wifi' && net.details?.strength != null) {
      quality = net.details.strength; // NetInfo fallback (0–100)
    }
  } else if (transport === 'cellular') {
    if (cell?.dbm != null) {
      dbm = cell.dbm;
      quality = cellQuality(cell.dbm);
    } else if (cell?.level != null) {
      quality = cell.level * 25;
    }
  }

  return {
    time: Date.now(),
    transport,
    connected: !!net.isConnected,
    wifi,
    cell,
    dbm,
    quality,
    native: isNativeAvailable,
    netinfo: net,
  };
}

type Ctx = { current: SignalSnapshot | null; history: SignalSnapshot[] };
const SignalContext = createContext<Ctx>({ current: null, history: [] });

export function SignalProvider({ children, intervalMs = 1000 }: { children: React.ReactNode; intervalMs?: number }) {
  const [state, setState] = useState<Ctx>({ current: null, history: [] });
  const alive = useRef(true);

  useEffect(() => {
    alive.current = true;
    let timer: ReturnType<typeof setTimeout>;
    const tick = async () => {
      try {
        const snap = await readSignal();
        if (!alive.current) return;
        setState((s) => ({ current: snap, history: [...s.history.slice(-89), snap] }));
      } finally {
        if (alive.current) timer = setTimeout(tick, intervalMs);
      }
    };
    requestRadioPermissions().finally(tick);
    return () => {
      alive.current = false;
      clearTimeout(timer);
    };
  }, [intervalMs]);

  return <SignalContext.Provider value={state}>{children}</SignalContext.Provider>;
}

export const useSignal = () => useContext(SignalContext);

/**
 * Take a reading for a map point.
 *
 * Android only refreshes the Wi-Fi RSSI every ~3 s (longer when the phone is still), and the modem
 * reports cell signal on its own schedule. A reading taken the instant you tap can therefore still
 * reflect where you were standing a few seconds ago. So we watch for `totalMs`, ignore the first
 * `settleMs`, and average what comes in after that.
 */
export async function sampleSignal(
  onProgress?: (secondsLeft: number) => void,
  totalMs = 6000,
  settleMs = 3000,
  gapMs = 400
): Promise<{ wifi: number | null; cell: number | null; snap: SignalSnapshot }> {
  const wifi: number[] = [];
  const cell: number[] = [];
  const start = Date.now();
  let snap = await readSignal();
  while (true) {
    const el = Date.now() - start;
    onProgress?.(Math.max(0, Math.ceil((totalMs - el) / 1000)));
    if (el >= settleMs) {
      if (snap.wifi?.rssi != null) wifi.push(snap.wifi.rssi);
      if (snap.cell?.dbm != null) cell.push(snap.cell.dbm);
    }
    if (el >= totalMs) break;
    await new Promise((r) => setTimeout(r, gapMs));
    snap = await readSignal();
  }
  const avg = (a: number[]) => (a.length ? Math.round(a.reduce((x, y) => x + y, 0) / a.length) : null);
  return { wifi: avg(wifi), cell: avg(cell), snap };
}
