import NetInfo, { NetInfoState } from '@react-native-community/netinfo';
import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { PermissionsAndroid, Platform } from 'react-native';
import {
  CellReading,
  getActiveTransport,
  getCellInfo,
  getWifiInfo,
  isNativeAvailable,
  WifiReading,
} from '../../modules/signal-strength';

export type Transport = 'wifi' | 'cellular' | 'ethernet' | 'vpn' | 'none' | 'other' | 'unknown';

export type SignalSnapshot = {
  time: number;
  transport: Transport;
  connected: boolean;
  wifi: WifiReading | null;
  cell: CellReading | null;
  /** Signal strength of the active connection, in dBm (null if unknown). */
  dbm: number | null;
  /** 0–100 score for the active connection. */
  quality: number | null;
  /** True when values come from the real radio (native module) rather than estimates. */
  native: boolean;
  netinfo?: NetInfoState;
};

export type SignalMetric = 'wifi' | 'cell';

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));

/** Wi-Fi RSSI: -30 dBm (amazing) … -90 dBm (unusable). */
export const wifiQuality = (rssi: number) => Math.round(clamp(((rssi + 90) / 60) * 100, 0, 100));
/** Cellular dBm: -70 dBm (excellent) … -120 dBm (no service). */
export const cellQuality = (dbm: number) => Math.round(clamp(((dbm + 120) / 50) * 100, 0, 100));

export function qualityFor(metric: SignalMetric, dbm: number) {
  return metric === 'wifi' ? wifiQuality(dbm) : cellQuality(dbm);
}

export function qualityLabel(q: number | null): string {
  if (q == null) return 'Unknown';
  if (q >= 80) return 'Excellent';
  if (q >= 60) return 'Good';
  if (q >= 40) return 'Fair';
  if (q >= 20) return 'Weak';
  return 'Very weak';
}

/** Red → orange → yellow → green → cyan for a 0–100 score. */
export function qualityColor(q: number | null): string {
  if (q == null) return '#6b7280';
  const stops: [number, [number, number, number]][] = [
    [0, [220, 38, 38]],
    [30, [249, 115, 22]],
    [55, [234, 179, 8]],
    [75, [34, 197, 94]],
    [100, [6, 182, 212]],
  ];
  for (let i = 1; i < stops.length; i++) {
    const [p1, c1] = stops[i];
    const [p0, c0] = stops[i - 1];
    if (q <= p1) {
      const t = (q - p0) / (p1 - p0);
      const c = c0.map((v, k) => Math.round(v + (c1[k] - v) * t));
      return `rgb(${c[0]},${c[1]},${c[2]})`;
    }
  }
  return 'rgb(6,182,212)';
}

async function requestRadioPermissions() {
  if (Platform.OS !== 'android') return;
  try {
    await PermissionsAndroid.requestMultiple([
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION,
      PermissionsAndroid.PERMISSIONS.READ_PHONE_STATE,
    ]);
  } catch {
    // user can still use the app; SSID / network type will be hidden
  }
}

/** Read everything once. Uses the native module when present, NetInfo otherwise. */
export async function readSignal(): Promise<SignalSnapshot> {
  const net = await NetInfo.fetch();
  const wifi = getWifiInfo();
  const cell = getCellInfo();
  const nativeTransport = getActiveTransport() as Transport | null;
  const transport: Transport = nativeTransport ?? ((net.type as Transport) || 'unknown');

  let dbm: number | null = null;
  let quality: number | null = null;

  if (transport === 'wifi') {
    if (wifi?.rssi != null) {
      dbm = wifi.rssi;
      quality = wifiQuality(wifi.rssi);
    } else if (net.type === 'wifi' && net.details?.strength != null) {
      quality = net.details.strength; // NetInfo fallback (0–100)
    }
  } else if (transport === 'cellular') {
    if (cell?.dbm != null) {
      dbm = cell.dbm;
      quality = cellQuality(cell.dbm);
    } else if (cell?.level != null) {
      quality = cell.level * 25;
    }
  }

  return {
    time: Date.now(),
    transport,
    connected: !!net.isConnected,
    wifi,
    cell,
    dbm,
    quality,
    native: isNativeAvailable,
    netinfo: net,
  };
}

type Ctx = { current: SignalSnapshot | null; history: SignalSnapshot[] };
const SignalContext = createContext<Ctx>({ current: null, history: [] });

export function SignalProvider({ children, intervalMs = 1000 }: { children: React.ReactNode; intervalMs?: number }) {
  const [state, setState] = useState<Ctx>({ current: null, history: [] });
  const alive = useRef(true);

  useEffect(() => {
    alive.current = true;
    let timer: ReturnType<typeof setTimeout>;
    const tick = async () => {
      try {
        const snap = await readSignal();
        if (!alive.current) return;
        setState((s) => ({ current: snap, history: [...s.history.slice(-89), snap] }));
      } finally {
        if (alive.current) timer = setTimeout(tick, intervalMs);
      }
    };
    requestRadioPermissions().finally(tick);
    return () => {
      alive.current = false;
      clearTimeout(timer);
    };
  }, [intervalMs]);

  return <SignalContext.Provider value={state}>{children}</SignalContext.Provider>;
}

export const useSignal = () => useContext(SignalContext);

/** Average a few fresh readings for a steadier map sample. */
export async function sampleSignal(count = 4, gapMs = 350): Promise<{ wifi: number | null; cell: number | null; snap: SignalSnapshot }> {
  const wifi: number[] = [];
  const cell: number[] = [];
  let snap = await readSignal();
  for (let i = 0; i < count; i++) {
    if (i > 0) {
      await new Promise((r) => setTimeout(r, gapMs));
      snap = await readSignal();
    }
    if (snap.wifi?.rssi != null) wifi.push(snap.wifi.rssi);
    if (snap.cell?.dbm != null) cell.push(snap.cell.dbm);
  }
  const avg = (a: number[]) => (a.length ? Math.round(a.reduce((x, y) => x + y, 0) / a.length) : null);
  return { wifi: avg(wifi), cell: avg(cell), snap };
}
